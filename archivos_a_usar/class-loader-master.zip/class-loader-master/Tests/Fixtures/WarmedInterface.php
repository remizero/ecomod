<?php

namespace Symfony\Component\ClassLoader\Tests\Fixtures;

interface WarmedInterface
{
}
