<?php

class PrefixCollision_C_B_Foo
{
    public static $loaded = true;
}
