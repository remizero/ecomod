<?php

namespace Symfony\Component\ClassLoader\Tests\Fixtures;

class WarmedClass extends DeclaredClass implements WarmedInterface
{
}
